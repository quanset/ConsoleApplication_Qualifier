﻿
/// <summary>
/// Use this to keep track of the results from "find the best loan".
/// </summary>


public class LoanCalculationResults
{
    public LoanCalculationResults()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    /// <summary>
    /// 
    /// </summary>
    public int RecommendedLoanAmount_Base{ get; set; }

    /// <summary>
    /// 
    /// </summary>
    public decimal RecommendedPayment_PrincipleAndInterest{ get; set; }

}

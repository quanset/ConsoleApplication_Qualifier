﻿using System;

/// <summary>
/// Class to find the loan they qualify for!
/// Figure out the max monthly payment the borrower is allowed.
/// Use the max monthly payment amount to "seek" for the maximum loan amount for each loan type.
/// </summary>

public class Qualifier
{
//        public Qualifier()
//        {
//            // TODO: Add constructor logic here
//        }

    /// <summary>
    /// CLIENT SPECIFIC METHOD - Do not change
    /// </summary>
    static public void setupBorrowerInitialData(LoanCommonInfo loanCommonInfo, Decimal DownPaymentPercentage, int MonthlyIncome, int MonthlyDebt, int CreditScore, int HOAFees)
    {
        loanCommonInfo.DownPaymentPercentage = DownPaymentPercentage;
        loanCommonInfo.Income_Monthly = MonthlyIncome;
        loanCommonInfo.Debt_Monthly = MonthlyDebt;
        loanCommonInfo.CreditScore = CreditScore;
        loanCommonInfo.HOA_Fees = HOAFees;


        InterestRates IR = new InterestRates();
        loanCommonInfo.LoanInfo_FHA30 = new LoanProviderInfo("FHA 30-year Loan", 30, IR.FHA30);
        loanCommonInfo.LoanInfo_FHA15 = new LoanProviderInfo("FHA 15-year Loan", 15, IR.FHA15);
        loanCommonInfo.LoanInfo_VA30 = new LoanProviderInfo("VA 30-year Loan", 30, IR.VA30);
        loanCommonInfo.LoanInfo_VA15 = new LoanProviderInfo("VA 15-year Loan", 15, IR.VA15);
        loanCommonInfo.LoanInfo_USDA30 = new LoanProviderInfo("USDA 30-year Loan", 30, IR.USDA30);
        loanCommonInfo.LoanInfo_CONV30 = new LoanProviderInfo("CONV 30-year Loan", 30, IR.CONV30);
        loanCommonInfo.LoanInfo_CONV15 = new LoanProviderInfo("CONV 15-year Loan", 30, IR.CONV15);
        

        calculateMaxPayment(loanCommonInfo);
    }

    /// <summary>
    /// Set the "common" data elements into the data structure: LoanCommonInfo
    /// </summary>
    static public void setupBorrowerInitialData(LoanCommonInfo loanCommonInfo, decimal DownPaymentPercentage, int MonthlyIncome, int MonthlyDebt, int CreditScore, int HOAFees, int dummyVariableToDistinguishMethodSignature)
    {
        loanCommonInfo.DownPaymentPercentage = DownPaymentPercentage;
        loanCommonInfo.Income_Monthly = MonthlyIncome;
        loanCommonInfo.Debt_Monthly = MonthlyDebt;
        loanCommonInfo.CreditScore = CreditScore;
        loanCommonInfo.HOA_Fees = HOAFees;

        loanCommonInfo.LoanInfo_FHA30 =  new LoanProviderInfo("FHA 30-year Loan",  30, 3.63);
        loanCommonInfo.LoanInfo_FHA15 =  new LoanProviderInfo("FHA 15-year Loan",  15, 3.25);
        loanCommonInfo.LoanInfo_VA30 =   new LoanProviderInfo("VA 30-year Loan",   30, 3.75);
        loanCommonInfo.LoanInfo_VA15 =   new LoanProviderInfo("VA 15-year Loan",   15, 3.25);
        loanCommonInfo.LoanInfo_USDA30 = new LoanProviderInfo("USDA 30-year Loan", 30, 3.63);
        loanCommonInfo.LoanInfo_CONV30 = new LoanProviderInfo("CONV 30-year Loan", 30, 4.13);
        loanCommonInfo.LoanInfo_CONV15 = new LoanProviderInfo("CONV 15-year Loan", 15, 3.25);
        loanCommonInfo.LoanInfo_xxx10 = new LoanProviderInfo("NEW xxx10", 10, 3.25);
        loanCommonInfo.LoanInfo_xxx20 = new LoanProviderInfo("NEW xxx20", 20, 3.25);

        calculateMaxPayment(loanCommonInfo);
    }

    // TODO: Al notified me that the max payment is now loan specific.   Need to move this logic out of the common area.
    /// <summary>
    /// The Max Payment is based on monthly income vs. monthly debt.
    ///   "This is the max you can afford on a loan"
    /// </summary>
    private static void calculateMaxPayment(LoanCommonInfo loanCommonInfo)
    {
        int maxPaymentAllowedBasedOnIncome = (int)(loanCommonInfo.Income_Monthly * 0.35);
        int maxPaymentAllowedBasedOnDebt = (int)(loanCommonInfo.Income_Monthly * 0.45) - loanCommonInfo.Debt_Monthly;

        if (maxPaymentAllowedBasedOnIncome > maxPaymentAllowedBasedOnDebt)
        {
            loanCommonInfo.Payment_Maximum = maxPaymentAllowedBasedOnDebt;
            // Hmmm.  Don't remember what this one is for:  //loanCommonInfo.Payment_Maximum = Lookup_MaxPaymentAllowedBasedOnDebt(loanCommonInfo.CreditScore, loanCommonInfo.DownPaymentPercentage, Qualifier.DebtRatio_House);
        }
        else
        {
            loanCommonInfo.Payment_Maximum = maxPaymentAllowedBasedOnIncome;
        }
    }

    public static double[,] DebtRatio_House = new double[11, 9] { { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { 0.00, 0.00, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02 }, { -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00 }, { -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00 }, { -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00 } };
    public static double[,] DebtRatio_Total = new double[11, 9] { { 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { 0.00, 0.00, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { 0.00, 0.00, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { 0.00, 0.00, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { 0.00, 0.00, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05 }, { -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00 }, { -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00 }, { -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00, -1.00 } };

    public double Lookup_MaxPaymentAllowedBasedOnDebt(int creditScore, decimal downPaymentPercentage, double[,] interestRateOffsetArray)
    {
//           setupLookupTableIndices(creditScore, downPaymentPercentage);
//           return interestRateOffsetArray[MortgageInsuranceColumnIndex, MortgageInsuranceRowIndex];
        return 0.0;
    }


    static public void DisplayLoanInformation(LoanCommonInfo loan_info)
    {
        DisplayCommonLoanInformation(loan_info);

        Console.WriteLine("FHA30 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_FHA30, 9999);
        Console.WriteLine("FHA15 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_FHA15, 9999);
        Console.WriteLine("VA30 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_VA30, 9999);
        Console.WriteLine("VA15 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_VA15, 9999);
        Console.WriteLine("USDA30 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_USDA30, 9999);
        Console.WriteLine("CONV30 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_CONV30, 9999);
        Console.WriteLine("CONV15 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_CONV15, 9999);
        Console.WriteLine("xxx10 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_xxx10, 9999);
        Console.WriteLine("xxx20 specific info follows: -----------------------------------");
        DisplayLoanSpecificInfo(loan_info.LoanInfo_xxx20, 9);
    }

    private static void DisplayLoanSpecificInfo(LoanProviderInfo loanSpecificInfo, int dummyVariableToDistinguishMethodSignature)
    {
        Console.WriteLine("Loan Type: {0}", loanSpecificInfo.LoanType);
        Console.WriteLine("Loan Term: {0} years ({1} months)", loanSpecificInfo.LoanTermYears, loanSpecificInfo.LoanTermMonths);
        Console.WriteLine("Max Loan Amount qualified for - Base: {0:C}", loanSpecificInfo.LoanAmount_Base);
        Console.WriteLine("Loan Amount - including upfront Mortgage Insurance: {0:C}", loanSpecificInfo.LoanAmount_Actual);
        Console.WriteLine("Annual Interest Rate BASE: {0}%", loanSpecificInfo.InterestRate_Annual_Base);
        Console.WriteLine("Annual Interest Rate OFFSET: {0}%", loanSpecificInfo.InterestRate_Annual_Offset);
        Console.WriteLine("Annual Interest Rate TOTAL: {0}%", loanSpecificInfo.InterestRate_Annual_Total);
        Console.WriteLine("Upfront Mortgage Insurance Rate: {0}%", loanSpecificInfo.UpfrontMortgageInsuranceRate);
        Console.WriteLine("Upfront Mortgage Insurance Amount: {0:C}", loanSpecificInfo.UpfrontMortgageInsurancePayment);
        Console.WriteLine("Monthly Mortgage Insurance Rate: {0}%", loanSpecificInfo.MonthlyMortgageInsuranceRate);
        Console.WriteLine("Monthly Mortgage Insurance Payment: {0:C}", loanSpecificInfo.MonthlyMortgageInsurancePayment);
        Console.WriteLine("Monthly Property Tax Rate: {0}%", loanSpecificInfo.MonthlyPropertyTaxRate);
        Console.WriteLine("Monthly Property Tax Payment: {0:C}", loanSpecificInfo.MonthlyPropertyTaxPayment);
        Console.WriteLine("Monthly P&I: {0:C}", loanSpecificInfo.PrincipleAndInterestPayment);
        Console.WriteLine("Total Payment (P&I + Insurance): {0:C}", loanSpecificInfo.TotalLoanPayment);
        Console.WriteLine();
    }


    /// <summary>
    /// Invoked when an input text file is provided to iterate through.
    /// Flat-format allows multiple scenarios to be read and compared more easily.
    /// </summary>
    static public void DisplayLoanInformation_FlatFormat(LoanCommonInfo loan_info)
    {
        DisplayCommonLoanInformation(loan_info);


        // Display header for the "loan specific" data.
        // The constant formatting string. It specifies the padding.
	    // ... A negative number means to left-align.
	    // ... A positive number means to right-align.
        string header = String.Format("{0,-20}{1,-5}{2,-15}{3,-15}{4,-10}{5,-10}{6,-10}{7,-15}{8,-20}{9,-15}{10,-15}{11,-15}{12,-25}{13,-15}{14,-15}\n",
                                        "Type", "Term", "MaxBase", "MaxLoanTotal", "IntBase", "IntOffset", "IntTotal", "UpfrontMIBase", 
                                        "UpfrontMIAmount", "MonthlyMIRate", "MonthlyMIPmt", "MonthlyPTRate", "MonthlyPTPayment", "MonthlyP&I", "TotalPayment");
        Console.WriteLine(header);

    //      Console.WriteLine("Type Term    MaxBase BaxLoanTotal    IntBase IntOffset   IntTotal    UpfrontMIBase   UpfrontMIAmount MonthlyMIRate   MonthlyMIPmt    MonthlyPTRate   MonthlyPTPayment    MonthlyP&I  TotalPayment");
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_FHA30);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_FHA15);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_VA30);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_VA15);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_USDA30);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_CONV30);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_CONV15);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_xxx10);
        DisplayLoanSpecificInfo_FlatFormat(loan_info.LoanInfo_xxx20);
    }

    private static void DisplayCommonLoanInformation(LoanCommonInfo loan_info)
    {
        Console.WriteLine("Common info from initial setups: -----------------------------------");
        Console.WriteLine("Credit Score      (input from client): {0}", loan_info.CreditScore);
        Console.WriteLine("Down Payment      (input from client): {0}%", loan_info.DownPaymentPercentage);
        Console.WriteLine("Income (monthly)  (input from client): {0:C}", loan_info.Income_Monthly);
        Console.WriteLine("Debt (monthly)    (input from client): {0:C}", loan_info.Debt_Monthly);
        Console.WriteLine("HOA Fees          (input from client): {0:C}", loan_info.HOA_Fees);
        Console.WriteLine("Maximum Payment allowed (Calculated by this program): {0:C}", loan_info.Payment_Maximum);
        Console.WriteLine("");
    }

    private static void DisplayLoanSpecificInfo_FlatFormat(LoanProviderInfo loanSpecificInfo)
    {
        string output;
        output = String.Format("{0,-20}{1,-5}{2,-15:C}{3,-15:C}{4,-10}{5,-10}{6,-10}{7,-15}{8,-20:C}{9,-15}{10,-15:C}{11,-15}{12,-25:C}{13,-15:C}{14,-15:C}",
            loanSpecificInfo.LoanType,
            loanSpecificInfo.LoanTermYears,
            loanSpecificInfo.LoanAmount_Base,
            loanSpecificInfo.LoanAmount_Actual,
            loanSpecificInfo.InterestRate_Annual_Base,
            loanSpecificInfo.InterestRate_Annual_Offset,
            loanSpecificInfo.InterestRate_Annual_Total,
            loanSpecificInfo.UpfrontMortgageInsuranceRate,
            loanSpecificInfo.UpfrontMortgageInsurancePayment,
            loanSpecificInfo.MonthlyMortgageInsuranceRate,
            loanSpecificInfo.MonthlyMortgageInsurancePayment,
            loanSpecificInfo.MonthlyPropertyTaxRate,
            loanSpecificInfo.MonthlyPropertyTaxPayment,
            loanSpecificInfo.PrincipleAndInterestPayment,
            loanSpecificInfo.TotalLoanPayment);
        Console.WriteLine(output);

        //Console.WriteLine();
    }

    /// <summary>
    /// CLIENT SPECIFIC DISPLAY METHOD - Do not change
    /// </summary>
    static public string DisplayLoanInformation(LoanCommonInfo loan_info, bool isThirty)
    {
        string results = string.Empty;
        //results = "<hr><ul>";
        //results += "<li>Common info from initial setups: -----------------------------------</li>";
        //results += "<li>" + String.Format("Credit Score : {0}", loan_info.CreditScore) + "</li>";
        //results += "<li>" + String.Format("Down Payment: {0}%", loan_info.DownPaymentPercentage) + "</li>";
        //results += "<li>" + String.Format("Income (monthly): {0:C}", loan_info.Income_Monthly) + "</li>";
        //results += "<li>" + String.Format("Debt (monthly): {0:C}", loan_info.Debt_Monthly) + "</li>";
        //results += "<li>" + String.Format("Maximum Payment allowed: {0:C}", loan_info.Payment_Maximum) + "</li>";
        //results += "</ul>";
        //results += "<hr>";

        if (isThirty)
        {
            results += "<table class=\"table table-striped\">";
            results += "<tr>";
            results += "</tr>";
            results += DisplayLoanSpecificInfo(loan_info.LoanInfo_FHA30);
            results += "</table>";
        }
        if (!isThirty)
        {
            results += "<table class=\"table table-striped\">";
            results += "<tr>";
            results += "</tr>";
            results += DisplayLoanSpecificInfo(loan_info.LoanInfo_FHA15);
            results += "</table>";
        }
        if (isThirty)
        {
            results += "<table class=\"table table-striped\">";
            results += "<tr>";
            results += "</tr>";
            results += DisplayLoanSpecificInfo(loan_info.LoanInfo_VA30);
            results += "</table>";
        }
        if (!isThirty)
        {
            results += "<table class=\"table table-striped\">";
            results += "<tr>";
            results += "</tr>";
            results += DisplayLoanSpecificInfo(loan_info.LoanInfo_VA15);
            results += "</table>";
        }
        if (isThirty)
        {
            results += "<table class=\"table table-striped\">";
            results += "<tr>";
            results += "</tr>";
            results += DisplayLoanSpecificInfo(loan_info.LoanInfo_USDA30);
            results += "</table>";
        }
        if (isThirty)
        {
            results += "<table class=\"table table-striped\">";
            results += "<tr>";
            results += DisplayLoanSpecificInfo(loan_info.LoanInfo_CONV30);
            results += "</table>";
        }
        if (!isThirty)
        {
            results += "<table class=\"table table-striped\">";
            results += "<tr>";
            results += "</tr>";
            results += DisplayLoanSpecificInfo(loan_info.LoanInfo_CONV15);
            results += "</table>";
        }


        return results;
    }

    /// <summary>
    /// CLIENT SPECIFIC DISPLAY METHOD - Do not change
    /// </summary>
    static private string DisplayLoanSpecificInfo(LoanProviderInfo loanSpecificInfo)
    {
        string returnLI = string.Empty;
        try
        {
            returnLI += "<tr><td colspan=2>" + String.Format("<h5>{0}</h5>", loanSpecificInfo.LoanType) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Loan Term:</td><td> {0} years ({1} months)", loanSpecificInfo.LoanTermYears, loanSpecificInfo.LoanTermMonths) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Max Loan Amount qualified for - Base:</td><td> {0:C}", loanSpecificInfo.LoanAmount_Base) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Loan Amount - including upfront Mortgage Insurance:</td><td> {0:C}", loanSpecificInfo.LoanAmount_Actual) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Annual Interest Rate BASE:</td><td> {0}%", loanSpecificInfo.InterestRate_Annual_Base) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Annual Interest Rate OFFSET:</td><td> {0}%", loanSpecificInfo.InterestRate_Annual_Offset) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Annual Interest Rate TOTAL:</td><td> {0}%", loanSpecificInfo.InterestRate_Annual_Total) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Upfront Mortgage Insurance Rate:</td><td> {0}%", loanSpecificInfo.UpfrontMortgageInsuranceRate) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Upfront Mortgage Insurance Amount:</td><td> {0:C}", loanSpecificInfo.UpfrontMortgageInsurancePayment) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Monthly Mortgage Insurance Rate:</td><td> {0}%", loanSpecificInfo.MonthlyMortgageInsuranceRate) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Monthly Mortgage Insurance Payment:</td><td> {0:C}", loanSpecificInfo.MonthlyMortgageInsurancePayment) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Monthly Property Tax Rate:</td><td> {0}%", loanSpecificInfo.MonthlyPropertyTaxRate) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Monthly Property Tax Payment:</td><td> {0:C}", loanSpecificInfo.MonthlyPropertyTaxPayment) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Monthly P&I:</td><td> {0:C}", loanSpecificInfo.PrincipleAndInterestPayment) + "</td></tr>";
            returnLI += "<tr><td>" + String.Format("Total Payment (P&I + Insurance):</td><td> {0:C}", loanSpecificInfo.TotalLoanPayment) + "</td></tr>";
        }
        catch (Exception ex)
        {
            returnLI += "Errored Out:" + ex.Message;
        }
        return returnLI;

    }
}
